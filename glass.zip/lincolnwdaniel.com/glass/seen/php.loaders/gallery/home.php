<?php
	use Parse\ParseObject;
	use Parse\ParseUser;
	use Parse\ParseQuery;
	use Parse\ParseACL;
	use Parse\ParsePush;
	use Parse\ParseInstallation;
	use Parse\ParseException;
	use Parse\ParseAnalytics;
	use Parse\ParseFile;
	use Parse\ParseCloud;

	$parse_current_user = ParseUser::getCurrentUser();
	if($parse_current_user){
		$parse_current_user_id = $parse_current_user->getObjectId();
	}
	$parse_images_query = new ParseQuery(ParseConstants::CLASS_IMAGE_UPLOAD);
	$parse_images_query->limit(1000);
	$parse_images_query->descending(ParseConstants::KEY_CREATED_AT);
	$parse_images = $parse_images_query->find();
	for ($i = 0; $i < count($parse_images); $i++) {
		$image = $parse_images[$i];

		$image_id = $image->getObjectId();
		
		$image_date = $image->getCreatedAt();
		$image_file = $image->get(ParseConstants::KEY_IMAGE_FILE);
		if( $image_file!= null ){ $image_file_url = $image_file->getURL(); }

		if($image_file_url){
			$image = '<li style="width:33%">';
				$image .= '<img src="'.$image_file_url.'" width="150px" height="150px" 
				onmouseover="popupSeen(&#39;'.$image_file_url.'&#39;)"
				onmouseout="popupHide()"/>';
				//$image .= '<span><img src="'.$image_file_url.'" width="500px" height="500px"/></span>';
			$image .= '</li>';

			$images.= $image;
		}
	}
?>