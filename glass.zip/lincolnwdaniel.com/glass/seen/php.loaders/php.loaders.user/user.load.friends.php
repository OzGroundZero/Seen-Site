<?php
	use Parse\ParseObject;
	use Parse\ParseUser;
	use Parse\ParseQuery;
	use Parse\ParseACL;
	use Parse\ParsePush;
	use Parse\ParseInstallation;
	use Parse\ParseException;
	use Parse\ParseAnalytics;
	use Parse\ParseFile;
	use Parse\ParseCloud;

	$parse_user_friends =  getParseUserFriendsFromId($parse_current_user_uid);

	for ($i = 0; $i < count($parse_user_friends); $i++) {
		$parse_friend = $parse_user_friends[$i];
		$parse_friend_id = $parse_friend->getObjectId();
		$parse_friend_u = $parse_friend->get(ParseConstants::KEY_USERNAME);
		$friend_avatar_url = getParseUserAvatarUrl($parse_friend_id);
		//set up friend display
		$user_friend = '<div id="friend'.$parse_friend_id.'" class="100_wide padding_20px border_bottom_1px_f0f0f0 
							hover_background_turquoise hover_text_color_white a_button"
							onclick="friendAction(\''.$parse_friend_id.'\', \''.$parse_friend_u.'\', \''.$friend_avatar_url.'\');"
						>';
			//the preview img
			$user_friend .= '<div class="display_inline_block padding_10px">';
			$user_friend .= '</div>';
			//end preview img
			//message info preview
			$user_friend .= '<div class="display_inline_block">';
				$user_friend .= '<div class="100_wide">';
					$user_friend .= '<div class="float_right">';
						$user_friend .= '<b class="text_size_18px">'.$parse_friend_u.'</b>';
					$user_friend .= '</div>';
					$user_friend .= '<div class="float_left" style="padding-right:10px">';
						$user_friend .= '<img style="width:48px; height:48px" src="'.$friend_avatar_url.'"/>';
					$user_friend .= '</div>';
				$user_friend .= '</div>';
				$user_friend .= '<div class="100_wide">';
					$user_friend .= '<div class="float_left">';
						if( $message_text_data!="" ){
							$user_friend .= substr($message_text_data, 0, strlen($message_text_data)*.6).'...';
						} 
					$user_friend .= '</div>';
				$user_friend .= '</div>';
			$user_friend .= '</div>';
		$user_friend .= '</div>';

		$user_friends.= $user_friend;
	}
?>