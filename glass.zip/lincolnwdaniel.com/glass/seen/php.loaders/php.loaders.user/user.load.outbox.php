<?php
	use Parse\ParseObject;
	use Parse\ParseUser;
	use Parse\ParseQuery;
	use Parse\ParseACL;
	use Parse\ParsePush;
	use Parse\ParseInstallation;
	use Parse\ParseException;
	use Parse\ParseAnalytics;
	use Parse\ParseFile;
	use Parse\ParseCloud;

	$parse_outbox_messages_query = new ParseQuery(ParseConstants::CLASS_MESSAGES);
	$parse_outbox_messages_query->limit(1000);
	$parse_outbox_messages_query->descending(ParseConstants::KEY_CREATED_AT);
	$parse_outbox_messages_query->equalTo(ParseConstants::KEY_SENDER_ID, $parse_current_user->getObjectId());
	$parse_outbox_messages_query->notEqualTo(ParseConstants::KEY_RECIPIENT_IDS, $parse_current_user->getObjectId());
	$parse_outbox_messages = $parse_outbox_messages_query->find();
	
	for ($i = 0; $i < count($parse_outbox_messages); $i++) {
		$message = $parse_outbox_messages[$i];
		$processed_recipient_uids = array();
		$processed_recipient_usernames = array();
		$recipient_usernames_string = "";
		$recipients_display = "";

		$message_id = $message->getObjectId();
		$message_sender = $message->get(ParseConstants::KEY_SENDER_NAME);
		//$message_date = $message->getCreatedAt();
		$message_type = $message->get(ParseConstants::KEY_FILE_TYPE);
		$message_text_data = $message->get(ParseConstants::KEY_TEXT_DATA);
		$message_recipients = $message->get(ParseConstants::KEY_RECIPIENT_IDS);
		$message_viewers = $message->get(ParseConstants::KEY_VIEWER_IDS);
		$message_file = $message->get(ParseConstants::KEY_FILE);
		if( $message_file!= null ){ 
			$message_file_url = $message_file->getURL();
		} else { $message_file_url = ""; }

		for($j = 0; $j < count($message_recipients); $j++){
			$parse_recipient_uid = $message_recipients[$j];
			$parse_recipient_user = getParseUserFromId($parse_recipient_uid);
			if($parse_recipient_user && !in_array($parse_user_uid, $processed_recipient_uids)) {
				$parse_recipient_u = $parse_recipient_user->get(ParseConstants::KEY_USERNAME);
				array_push($processed_recipient_uids, $parse_recipient_uid);
				array_push($processed_recipient_usernames, $parse_recipient_u);
				if( $j < count($message_recipients)-1 ){
					//not the last element in the array
					$recipient_usernames_string.= $parse_recipient_u.', ';
				} else {
					//this is last element in the array
					$recipient_usernames_string.= $parse_recipient_u.'';
				}
				$parse_recipient_url = getParseUserAvatarUrl($parse_recipient_uid);

				$recipient_display = createOutBoxRecipientDisplay($parse_recipient_uid, $parse_recipient_u, $parse_recipient_url);
				$recipients_display .= $recipient_display;
			}
		}


		$outbox_message = '<div id="message'.$message_id.'" class="100_wide padding_20px border_bottom_1px_f0f0f0 
							hover_background_turquoise hover_text_color_white"
						>';
			//the preview img
			$outbox_message .= '<div class="a_button display_inline_block padding_10px" onclick="clickOn(\'showMessage'.$message_id.'\');">
								<button id="showMessage'.$message_id.'" style="display:none" onclick="showMessage(\''.$message_id.'\', &#39;You&#39;,
							 	\''.$message_date.'\', \''.$message_type.'\', \''.$recipient_usernames_string.'\', \''.$message_file_url.'\', &#39;9326s&#39;);"
							>show message</button>';
			if( ($message_viewers != null) && in_array($parse_current_user_uid, $message_viewers)){
				//the user has seen this message
				if($message_type == ParseConstants::TYPE_IMAGE){
					$outbox_message .= '<img src="images/vectors/image_grey.svg" alt="Picture">';
				} else if($message_type == ParseConstants::TYPE_VIDEO){
					$outbox_message .= '<img src="images/vectors/play_grey.svg" alt="Picture">';
				} else if($message_type == ParseConstants::TYPE_TEXT){
					$outbox_message .= '<img src="images/vectors/pen_paper_grey.svg" alt="Text">';
				}
			} else {
				//the user has not seen this message yet
				if($message_type == ParseConstants::TYPE_IMAGE){
					$outbox_message .= '<img src="images/vectors/image_blue.svg" alt="Picture">';
				} else if($message_type == ParseConstants::TYPE_VIDEO){
					$outbox_message .= '<img src="images/vectors/play_blue.svg" alt="Picture">';
				} else if($message_type == ParseConstants::TYPE_TEXT){
					$outbox_message .= '<img src="images/vectors/pen_paper_blue.svg" alt="Text">';
				}
			}
			$outbox_message .= '</div>';
			//end preview img
			//message info preview
			$outbox_message .= '<div class="display_inline_block a_button" 
								onclick="clickOn(\'showMessage'.$message_id.'\');">';
				$outbox_message .= '<div class="100_wide">';
					$outbox_message .= '<div class="float_left">';
						$outbox_message .= '<b class="text_size_18px">You</b>';
					$outbox_message .= '</div>';
					$outbox_message .= '<div class="">';
						$outbox_message .= ''.$message_date.'';
					$outbox_message .= '</div>';
				$outbox_message .= '</div>';
				$outbox_message .= '<div class="100_wide">';
					$outbox_message .= '<div class="float_left">';
						if( $message_text_data!="" ){
							$outbox_message .= substr($message_text_data, 0, strlen($message_text_data)*.6).'...';
						} 
					$outbox_message .= '<span id="messageTextData'.$message_id.'" style="display:none">'.$message_text_data.'</span></div>';
				$outbox_message .= '</div>';
			$outbox_message .= '</div>';
			$outbox_message .= '<div class="display_inline_block float_right">';
				$outbox_message .= '<img id="deleteMessage'.$message_id.'" class="a_button" src="images/design.android.material/ic_close_24px.svg" alt="Text" 
										onclick="showMessage(\''.$message_id.'\', &#39;You&#39;,
							 	\''.$message_date.'\', \''.$message_type.'\', \''.$recipient_usernames_string.'\', \''.$message_file_url.'\', &#39;9305d&#39;);"
									>';
			$outbox_message .= '</div>';
			$outbox_message .= '<div class="100_wide" style="margin-left:50px">'.$recipients_display.'</div>';
		$outbox_message .= '</div>';

		$outbox_messages.= $outbox_message;
	}
?>