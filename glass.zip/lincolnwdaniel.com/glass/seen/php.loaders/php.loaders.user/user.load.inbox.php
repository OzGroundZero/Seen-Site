<?php
	use Parse\ParseObject;
	use Parse\ParseUser;
	use Parse\ParseQuery;
	use Parse\ParseACL;
	use Parse\ParsePush;
	use Parse\ParseInstallation;
	use Parse\ParseException;
	use Parse\ParseAnalytics;
	use Parse\ParseFile;
	use Parse\ParseCloud;


	$parse_current_user = ParseUser::getCurrentUser();
	$parse_current_user_id = $parse_current_user->getObjectId();
	$parse_inbox_messages_query = new ParseQuery(ParseConstants::CLASS_MESSAGES);
	$parse_inbox_messages_query->limit(1000);
	$parse_inbox_messages_query->descending(ParseConstants::KEY_CREATED_AT);
	$parse_inbox_messages_query->equalTo(ParseConstants::KEY_RECIPIENT_IDS, $parse_current_user->getObjectId());
	$parse_inbox_messages_query->notEqualTo(ParseConstants::KEY_HIDER_IDS, $parse_current_user->getObjectId());
	$parse_inbox_messages = $parse_inbox_messages_query->find();
	for ($i = 0; $i < count($parse_inbox_messages); $i++) {
		$message = $parse_inbox_messages[$i];

		$message_id = $message->getObjectId();
		$message_sender = $message->get(ParseConstants::KEY_SENDER_NAME);
		//$message_date = $message->getCreatedAt();
		$message_type = $message->get(ParseConstants::KEY_FILE_TYPE);
		$message_text_data = $message->get(ParseConstants::KEY_TEXT_DATA);
		$message_viewers = $message->get(ParseConstants::KEY_VIEWER_IDS);
		$message_file = $message->get(ParseConstants::KEY_FILE);
		if( $message_file!= null ){
			$message_file_url = $message_file->getURL();
		} else {
			$message_file_url = "";
		}

		$inbox_message = '<div id="message'.$message_id.'" class="100_wide padding_20px border_bottom_1px_f0f0f0 
							hover_background_turquoise hover_text_color_white a_button">';
			$inbox_message .= '<div class="a_button display_inline_block padding_10px" onclick="clickOn(\'showMessage'.$message_id.'\');">
								<button id="showMessage'.$message_id.'" style="display:none" onclick="showMessage(\''.$message_id.'\', \''.$message_sender.'\',
							 	\''.$message_date.'\', \''.$message_type.'\', \''.$recipient_usernames_string.'\', \''.$message_file_url.'\', &#39;9326s&#39;);"
							>show message</button>';
			//the preview img
			if( ($message_viewers != null) && in_array($parse_current_user_id, $message_viewers)){
				//the user has seen this message
				if($message_type == ParseConstants::TYPE_IMAGE){
					$inbox_message .= '<img src="images/vectors/image_grey.svg" alt="Picture">';
				} else if($message_type == ParseConstants::TYPE_VIDEO){
					$inbox_message .= '<img src="images/vectors/play_grey.svg" alt="Picture">';
				} else if($message_type == ParseConstants::TYPE_TEXT){
					$inbox_message .= '<img src="images/vectors/pen_paper_grey.svg" alt="Text">';
				}
			} else {
				//the user has not seen this message yet
				if($message_type == ParseConstants::TYPE_IMAGE){
					$inbox_message .= '<img src="images/vectors/image_blue.svg" alt="Picture">';
				} else if($message_type == ParseConstants::TYPE_VIDEO){
					$inbox_message .= '<img src="images/vectors/play_blue.svg" alt="Picture">';
				} else if($message_type == ParseConstants::TYPE_TEXT){
					$inbox_message .= '<img src="images/vectors/pen_paper_blue.svg" alt="Text">';
				}
			}
			$inbox_message .= '</div>';
			//end preview img
			//message info preview
			$inbox_message .= '<div class="display_inline_block"
								onclick="clickOn(\'showMessage'.$message_id.'\');">';
				$inbox_message .= '<div class="100_wide">';
					$inbox_message .= '<div class="float_left">';
						$inbox_message .= '<b class="text_size_18px">'.$message_sender.'</b>';
					$inbox_message .= '</div>';
					$inbox_message .= '<div class="float_right">';
						$inbox_message .= ''.$message_date.'';
					$inbox_message .= '</div>';
				$inbox_message .= '</div>';
				$inbox_message .= '<div class="100_wide">';
					$inbox_message .= '<div class="float_left">';
						if( $message_text_data!="" ){
							$inbox_message .= substr($message_text_data, 0, strlen($message_text_data)*.6).'...';
						} 
					$inbox_message .= '<span id="messageTextData'.$message_id.'" style="display:none">'.$message_text_data.'</span></div>';
				$inbox_message .= '</div>';
			$inbox_message .= '</div>';
			$inbox_message .= '<div class="display_inline_block float_right">';
				$inbox_message .= '<img id="hideMessage'.$message_id.'" class="a_button" src="images/design.android.material/ic_close_24px.svg" alt="Text" 
										onclick="showMessage(\''.$message_id.'\', &#39;You&#39;,
							 	\''.$message_date.'\', \''.$message_type.'\', \''.$fkV.'\', \''.$message_file_url.'\', &#39;9902h&#39;);"
									>';
			$inbox_message .= '</div>';
		$inbox_message .= '</div>';

		$inbox_messages.= $inbox_message;
	}
?>