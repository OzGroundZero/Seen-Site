<?php
	require 'php.apis/parse.com/parse-php-sdk-master/autoload.php';
	use Parse\ParseClient;
	use Parse\ParseSessionStorage;
	session_start();
	ParseClient::initialize('UxkZAm1ZGbbMETbbGiUiJEpOnxpzN9agWwZHBlh1', '3hWzrJkFgmvkj3SvL2679ektS4dMob0azV0cmoIa', 'MFyMGy34tQ8RUraghMnraLDd6NolGntrKyjKrvmK');
	// set session storage
	ParseClient::setStorage( new ParseSessionStorage() );
?>