<script type="text/javascript"> 
$(function() {
  $('#searchButton').click(
    function() {
      var action = "search_users";
      var searchTerm = $('#searchTerm').val();
      $('#searchButton').html('searching...');
      var ajax = ajaxObj("POST", "parse.api.custom.addon.php");
      ajax.onreadystatechange = function() {
        $('#searchButton').html('Search');
        if(ajaxReturn(ajax) == true) {
          var dataArray = ajax.responseText.split("|");
          var responseCode = dataArray[0].trim();
          if(dataArray[1]){
            var responseMessage = dataArray[1].trim();
          } else {
            showAlert("Search Failed", ajax.responseText, "", "")
          }
          
          if( responseCode != "action_success") {
            $('#searchResults').html(responseMessage);
          } else {
            $('#searchResults').html(responseMessage);
          }
        }
      }
      ajax.send("action="+action+"&search_term="+searchTerm);   
    }
  );  
});
</script>