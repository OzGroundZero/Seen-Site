<script type="text/javascript"> 
$(function() {

  var file;

                // Set an event listener on the Choose File field.
                $('#fileselect').bind("change", function(e) {
                  var files = e.target.files || e.dataTransfer.files;
                  // Our file var now holds the selected file
                  file = files[0];
                });

                // This function is called when the user clicks on Upload to Parse. It will create the REST API request to upload this image to Parse.


                $('#uploadbutton').click(function() {
                  var serverUrl = 'https://api.parse.com/1/files/' + file.name;

                  $.ajax({
                    type: "POST",
                    beforeSend: function(request) {
                      request.setRequestHeader("X-Parse-Application-Id", parse_app_id);
                      request.setRequestHeader("X-Parse-REST-API-Key", parse_rest_api_id);
                      request.setRequestHeader("Content-Type", file.type);
                    },
                    url: serverUrl,
                    data: file,
                    processData: false,
                    contentType: false,
                    success: function(data) {

                      var myimage = new Parse.Object("userImages");
                      myimage.set({imagetitle: "avatar"+"<?php echo $parse_current_user->getObjectId();?>"});
                      myimage.set({imageurl: data.url});
                      myimage.set({imagefile: {"name": data.name,"url": data.url,"__type": "File"}});
                      myimage.save();

                      //update UI with uploaded image
                      updateUIWithNewAvatar(data.url);
                      


                    },
                    error: function(data) {
                      var obj = jQuery.parseJSON(data);
                      alert(obj.error);
                    }
                  });
});


});

function updateUIWithNewAvatar(imgUrl){
  var updateLogProfileAvatar = document.getElementById("logProfileAvatar");
  var displayNewAvatar = document.getElementById("newAvatar");
  updateLogProfileAvatar.src = imgUrl;
  displayNewAvatar.src = imgUrl;
}
</script>