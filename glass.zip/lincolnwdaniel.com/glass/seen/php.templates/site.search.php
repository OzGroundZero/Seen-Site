<div class="padding_10px background_color_white margin_bottom_10px">
	<h2 class="text_align_center padding_10px">Search</h2>
	<?php
		include_once("php.templates/php.templates.search/search.form.php"); 
		include_once("php.templates/php.templates.search/search.users.php");
	?>
	
</div>
