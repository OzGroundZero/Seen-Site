<meta charset="utf-8">
<meta name="author" content="pixelhint.com">
<meta name="description" content="Magnetic is a stunning responsive HTML5/CSS3 photography/portfolio website template"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0" />
<link rel="stylesheet" type="text/css" href="css/reset.css">
<link rel="stylesheet" type="text/css" href="css/main.css">
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
 <!-- Custom Theme files -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href="css/style.base.css" rel='stylesheet' type='text/css' />
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/main.js"></script>

<?php 
//icons must come before other scripts and includes
include_once("php.includes/icons.php");?>

<script src="http://lincolnwdaniel.com/glass/seen/js/main.js"></script>
<?php include_once("php.templates/php.templates.vitals/vitals.site.html.elements.php");?>




