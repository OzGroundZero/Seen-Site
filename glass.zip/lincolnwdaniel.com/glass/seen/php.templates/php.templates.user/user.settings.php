<div class="padding_10px background_color_white margin_bottom_10px">
	<h2 class="text_align_center padding_10px">Personal Info</h2>

	<table>
		<tr>
			<td class="padding_10px">Id:</td>
			<td><?php echo $parse_current_user_uid;?></td>
		</tr>
		<tr>
			<td class="padding_10px">Username:</td>
			<td><?php echo $parse_current_user_u;?></td>
		</tr>
		<tr>
			<td class="padding_10px">Email:</td>
			<td><?php echo $parse_current_user_e;?></td>
		</tr>
	</table>
</div>