<?php 
include("php.loaders/gallery/home.php");
$thisIsHomeGalleryPage = true;
?>
<style type="text/css">
.seen_image_container{
	display:inline-block;
}
.seen_image{
	width:300px;
	height:300px;
	border-radius: 100%;
	display:inline-block;
}
.seen_image:hover{
	position:fixed;
	width:60%;
	height:60%;
}

ul.enlarge{
	list-style-type:none; /*remove the bullet point*/
	margin-left:0;
}
ul.enlarge li{
	display:inline-block; /*places the images in a line*/
	position: relative;
	z-index: 0; /*resets the stack order of the list items - later we'll increase this*/
	
}
ul.enlarge img{
	padding: 0px;
}
ul.enlarge span{
	position:absolute;
	bottom:0;
	left: -9999px;
	
	font-family: 'Droid Sans', sans-serif;
	font-size:.9em;
	text-align: center; 
	color: #495a62; 
}
ul.enlarge li:hover{
	z-index: 50;
	cursor:pointer;
}
ul.enlarge span img{
	position: relative;
}
ul.enlarge li:hover span{ 
	bottom: -100px; /*the distance from the bottom of the thumbnail to the top of the popup image*/
	left: 20px; /*distance from the left of the thumbnail to the left of the popup image*/
}
ul.enlarge li:hover:nth-child(2) span{
	left: -100px; 
}
ul.enlarge li:hover:nth-child(3) span{
	left: -200px; 
}
</style>
<script type="text/javascript">
	function popupSeen(url){
		var welcomeInfo = document.getElementById('welcomeInfo');
		var popup = document.getElementById('popupImg');

		if(url==""){ 
			welcomeInfo.style.display = "block";
			popup.style.display = "none"; 
		}
		else {
			welcomeInfo.style.display = "none";
			popup.style.display = "inline-block";
			popup.src = url;
		}
	}
</script>
<div class="margin_bottom_50px margin_0px" onmouseout="popupSeen('')">
	<div style="width:67.5%; display:inline-block; position:fixed; right:0">
		<div id="welcomeInfo" class="container">
			<h2>Welcome to Seen</h2>
			<h3>Capture Life & Carry On</h3>
			<br><br>
			<p class="text_small">Please understand that by using this application, you give up claim to privacy.</p>
		</div>
		<img id="popupImg" style="z-index:50">
	</div>
	<div style="width:33%; display:inline-block">
		<ul class="enlarge">
			<?php echo $images;?>
		</ul>

		<?php include_once("php.templates/site.footer.php");?>
	</div>
</div>