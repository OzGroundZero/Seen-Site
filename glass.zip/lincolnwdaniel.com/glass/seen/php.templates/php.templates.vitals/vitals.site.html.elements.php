<?php
	$dynamicPopupDiv = '<div id="dynamicPopupDiv"></div>';
?>