<!--copy-right-->
<div class="copy-right">
	<p><a style="font-size:8px;" href="http://lucystudios.lincolnwdaniel.com/">Lucy Studios</a></p>
</div>
<!--//copy-right-->