<nav class="top-header padding_2px" style="background-color:transparent;margin-top:300px">
	<a class="p-btn text_small" href="settings">Settings</a>
	<a class="p-btn text_small" href="terms" class="padding-5px">Terms & Conditions of Use</a>
	<a class="p-btn text_small" href="terms#privacy">Privacy Policies (Nonexistent)</a>
	<a class="p-btn text_small" href="terms">Other Nonexistening Policies</a>
</nav><!-- end navigation menu -->
	

	