<!--copy-right-->
<div class="copy-right">
	<p><a class="text_small text_color_clouds" href="http://lucystudios.lincolnwdaniel.com/">Lucy Studios</a></p>
</div>
<!--//copy-right-->