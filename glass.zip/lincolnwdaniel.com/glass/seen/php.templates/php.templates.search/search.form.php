<form onsubmit="retun false;"> 
	<fieldset>
		<div class="text-boxs">
			<span class="text-box">
				<input id="searchTerm" type="text" id="fileselect" placeholder="Search for friends...">
			</span>
		</div>
		<a id="searchButton" class="p-btn text_smaller a_button" style="border: none;"/>Search</a>
	</fieldset> 
</form>